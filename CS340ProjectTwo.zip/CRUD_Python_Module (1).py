from typing import Any, Dict, List, Optional
from pymongo import MongoClient


class AnimalShelter:
    """CRUD for 'animals' collection in 'AAC' database."""

    def __init__(
        self,
        user: str = "joseph",
        password: str = "password",
        host: str = "127.0.0.1",
        port: int = 27017,
        db_name: str = "AAC",
        collection_name: str = "animals",
    ):
        uri = f"mongodb://{user}:{password}@{host}:{port}/?authSource={db_name}"
        self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        # Force a connection error early if auth/host is wrong
        self.client.admin.command("ping")
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def create(self, data: Dict[str, Any]) -> bool:
        try:
            if not isinstance(data, dict) or not data:
                return False
            self.collection.insert_one(data)
            return True
        except Exception:
            return False

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None
    ) -> List[Dict[str, Any]]:
        try:
            if query is None or not isinstance(query, dict):
                query = {}
            cur = self.collection.find(query, projection)
            return list(cur)
        except Exception:
            return []

    def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> int:
        try:
            if not query or not new_values:
                return 0
            result = self.collection.update_many(query, {"$set": new_values})
            return int(result.modified_count)
        except Exception:
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        try:
            if not query:
                return 0
            result = self.collection.delete_many(query)
            return int(result.deleted_count)
        except Exception:
            return 0
